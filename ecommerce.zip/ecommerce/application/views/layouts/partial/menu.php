<div class="navbar navbar-inverse">
      <div class="navbar-inner">
        <div class="container">
          <button data-target=".nav-collapse" data-toggle="collapse" class="btn btn-navbar" type="button">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <!-- <a href="./index.html" class="brand">Menu</a> -->
          <div class="nav-collapse collapse">
            <ul class="nav">
              <li class="">
                <a href="<?php echo base_url();?>">Home</a>
              </li>
              <li class="">
                <a href="#">A Empresa</a>
              </li>
              <li class="">
                <a href="#">Nossos Produtos</a>
              </li>
              <li class="">
                <a href="#">Suporte Técnico</a>
              </li>
              <li class="">
                <a href="#">Contato</a>
              </li>
              <li class="active">
                <form class="navbar-search pull-left" action="">
					<input class="search-query span2" type="text" placeholder="Search">
				</form>
              </li>
            </ul>
          </div>
        </div>
      </div>
</div>