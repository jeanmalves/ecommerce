<?php
$config['pagseguro_email'] = 'seuemail@doPagseguro';
$config['pagseguro_token'] = '';
?>
