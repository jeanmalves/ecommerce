<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
************************************************************************
PagSeguro Config File
************************************************************************
*/

$config = array();

$config['email_pagseguro'] = "your@email.com";
$config['token_pagseguro'] = "your_token_here";
?>