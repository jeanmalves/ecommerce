<h3>Nova mensagem da se��o "Fale Conosco" do site Job Web Design</h3>
<br/>
<p><strong>Nome: </strong><?php echo $nome; ?></p>
<p><strong>E-mail: </strong><?php echo $email; ?></p>
<p><strong>Telefone: </strong><?php echo $fone; ?></p>
<p><strong>Assunto: </strong><?php echo $assunto; ?></p>
<p><strong>Mensagem: </strong><?php echo $mensagem; ?></p>