ecommerce
=========

Sistema E-commerce a fins de estudo para a disciplina de Produção e Logística.
Será adotado o padrão MVC usando CodeIgniter Framework(detalhes vide documentação: www.ellislab.com/codeigniter).
